# ICCMA'23

The files in this directory are sufficient to launch one of the dynamic solvers.
Proceed this way:

1. in source folder, compile in release mode: `cargo build --release`
2. edit `crustabri.py`: keep one of the lines 40, 41 to select the solver
    1.1 in case you selected the solver that uses an external IPASIR library, edit line 41 accordingly
3. execute `dynamic_track.py`, eg.: `time python3.11 dynamic_track.py DC-CO BA_200_0_2.af BA_200_0_2.af.arg`
